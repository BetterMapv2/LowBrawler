import config from "../../config";
import { chat, prefix } from "../../utils/utils";

var index = 0;
let timeSent 

const lowballMessages = [
    `Lowballing with ${config().purse} purse hihi :pvp:`,
    `Lowballing ${config().purse} purse! No clowns <3`,
    `${config().purse} LOWBALLING purse! visit me! No Time Wasters o/`,
    `Lowballing w ${config().purse}! visit me! :thinking:`
];

function convertExpression(expression) {
    expression = expression.replace(/b/g, '*1e9').replace(/m/g, '*1e6').replace(/k/g, '*1e3');
    return expression;
}
function formatNumberWithCommas(number) {
    var parts = number.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}
register("command", (expression) => {
    try {
        var result = formatNumberWithCommas(eval(convertExpression(expression)));
        ChatLib.chat(prefix + expression + "§a = §r" + result);
    } catch (e) {
        ChatLib.chat(prefix + "§cError in calculation");
    }
}).setName("calc").setAliases("eval", "math");

function sendLowballMessage() {
    if (Date.now() - timeSent < 5000) return chat(`&cYou're spamming this!`)
    chat(`&aSending Lowball Message ${index + 1}/${lowballMessages.length}`)
    ChatLib.command(`ac ${lowballMessages[index]}`)
    timeSent = Date.now()
    if (index == lowballMessages.length-1) index = 0
    else index++
}

const lowballButton = new KeyBind("Lowball Message", Keyboard.KEY_NONE, "LowBalling");

lowballButton.registerKeyPress(() => {
    sendLowballMessage();
});

// Lowball Command with /lbcalc
const commandRegister = register("command", (...args) => {
    try {
        ChatLib.chat(`&7&m${ChatLib.getChatBreak(" ")}`);
        ChatLib.chat("§1§lPRICES UNDER HERE ARE FOR ITEMS")
        ChatLib.chat(prefix + "§9§lLowball on §6Item: §9" + args + " §f= §6§l" + formatNumberWithCommas(eval(convertExpression(args[0]))));
        ChatLib.chat("");
        ChatLib.chat("§6§lAH Tax: §6§l" + formatNumberWithCommas(eval(convertExpression(args[0]))*0.035));
        ChatLib.chat("§6§lPrice §c- §6§lTax: §6§l" + formatNumberWithCommas(eval(convertExpression(args[0]))*0.965));
        ChatLib.chat(`&7&m${ChatLib.getChatBreak(" ")}`);
        ChatLib.chat("§2§l8% Lowball: §6§l" + formatNumberWithCommas(eval(convertExpression(args[0]))*0.92));
        ChatLib.chat("§9§l10% Lowball: §6§l" + formatNumberWithCommas(eval(convertExpression(args[0]))*0.9));
        ChatLib.chat("§6§l12% Lowball: §6§l" + formatNumberWithCommas(eval(convertExpression(args[0]))*0.88));
        ChatLib.chat("§4§l15% Lowball: §6§l" + formatNumberWithCommas(eval(convertExpression(args[0]))*0.85));
        ChatLib.chat(`&7&m${ChatLib.getChatBreak(" ")}`);
    } catch (e) {
        ChatLib.chat(prefix + "§cError in calculation");
    }
}).setName("lbcalc")


export function toggle() {
    return commandRegister.register();
}
export default { toggle };