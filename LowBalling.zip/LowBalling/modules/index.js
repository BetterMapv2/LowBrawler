import chatEmotes from "./chatEmotes"
import commands from "./commands"
import lowballing from "./lowballing";
import slotBinding from "./slotBinding";


export const modules = [
   commands, , chatEmotes, diamanteAlert, invincibilityMessages, kickMsg, pfoverlay, relicTimes, termTimestamps, wardrobeKeybinds, watcherMoveDisplay, slotBinding, autoLeap, alerts, locationMessages, doorSkip, partyFinder, dungeonStats, spawnTimers, lowballing, bloodCamp, secretHighlight, autoEther, invincibilityTimers, fastLeap, dragPrio, secretTriggerbot, relicLook
]

export function refresh_modules() {
    modules.forEach(name => {
        name.toggle() 
    })
}
export default { refresh_modules };