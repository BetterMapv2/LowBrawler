import Settings from "../Amaterasu/core/Settings"
import DefaultConfig from "../Amaterasu/core/DefaultConfig"
import { chat, mod_chat } from "./utils/utils"
import gui_config from "./gui_config"
import { data } from "./utils/data";
export let recently_closed = false;

const defConfig = new DefaultConfig("LowBalling", "data/settings.json")

defConfig

    .addSwitch({
        category: "General",
        configName: "toggle",
        title: "&5&lToggle Lowball mod",
        description: "Decides whether all features of this mod are &aenabled&7/&cdisabled&7.",
        registerListener(previousvalue, newvalue) {
            mod_chat(`Main Toggle ${newvalue ? "&aEnabled" : "&cDisabled"}`)
        }
    })
    .addSwitch({
        category: "General",
        configName: "debug",
        title: "Debug Mode",
        description: "Debug stuff, ignore this.",
        registerListener(previousvalue, newvalue) {
            mod_chat(`Debug Mode ${newvalue ? "&aEnabled" : "&cDisabled"}`)
        }
    })
    .addSwitch({
        category: "Slot Binding",
        configName: "slotBindingToggle",
        title: "&9Toggle Slot Binding",
        description: "Decides wether all features in Slot Binding are &aenabled&7/&cdisabled&7.",
        registerListener(previousvalue, newvalue) {
            mod_chat(`Slot Binding Toggle ${newvalue ? "&aEnabled" : "&cDisabled"}`)
        }
    })
    .addTextInput({
        category: "Slot Binding",
        configName: "slotBindingswapSound",
        title: "Swap Sound",
        description: "Sound used for slot binding.",
        value: "note.pling",
        placeHolder: "note.pling",
        subcategory: "Settings"
    })
    .addTextInput({
        category: "Lowballing",
        configName: "purse",
        title: "Purse",
        description: "Purse for Lowball Message",
        registerListener(previousvalue, newvalue) {
            mod_chat(`Lowballing ${newvalue ? "&aEnabled" : "&cDisabled"}`)
        } 
    })
    .addSwitch({
        category: "Random",
        configName: "chatEmotes",
        title: "Chat Emotes",
        description: "Allows you to use MVP++ emotes as any rank. ",
        subcategory: "Party Chat"
    })
  
const config = new Settings("LowBalling", defConfig, "templates/colorScheme.json", "§5Lowball Addons §7by §6BetterMap§7")
.setPos(10, 10)
.setSize(80, 80)
.apply()
.setCommand("LA", ["Lowball", "LowballAddons", "LowAddons"])
.onCloseGui(() => {
    data.recently_closed = true
    data.save()
})
export default () => config.settings